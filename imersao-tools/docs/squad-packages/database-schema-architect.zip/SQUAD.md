---
name: Database Schema Architect
version: 1.0.0
category: dados
price: 4.98
agents: 2
author: "[IA]AVANÇADA PT"
---

Especialista em schema design, migrations e RLS policies.
